using Inventario.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using CapaServices;


namespace Inventario.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;



        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            CapaServices.Inventario Getdata= new CapaServices.Inventario();

            string ResultSelec = Getdata.GetInventarios();

            return View();
        }

        public JsonResult Getinventario()
        {
            CapaServices.Inventario Getdata = new CapaServices.Inventario();

            string ResultSelec = Getdata.GetInventarios();

            return Json( ResultSelec);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
