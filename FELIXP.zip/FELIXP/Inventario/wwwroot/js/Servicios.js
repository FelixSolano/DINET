$(document).ready(function () {

    fnListar();
});
var URL_BASE = "http://localhost:5127";
function fnListar() {

    $.get("http://localhost:5127" + "/Home/Getinventario", function (response) {

        var tablaDatos = $("#tbdInventario");

        console.log(response);

        var arregloDatos = JSON.parse(response);
        console.log(arregloDatos);

        $.each(arregloDatos, function (index, item) {
            var filaHTML = "<tr><td>";
            filaHTML += item.COD_CIA + "</td>";
            filaHTML += "<td>" + item.COMPANIA_VENTA_3 + "</td>";
            filaHTML += "<td>" + item.ALMACEN_VENTA + "</td>";
            filaHTML += "<td>" + item.TIPO_MOVIMIENTO + "</td>";
            filaHTML += "<td>" + item.TIPO_DOCUMENTO + "</td>";
            filaHTML += "<td>" + item.NRO_DOCUMENTO + "</td>";
            filaHTML += "<td>" + item.COD_ITEM_2 + "</td>";
            filaHTML += "<td>" + item.PROVEEDOR + "</td>";
            filaHTML += "<td>" + item.ALMACEN_DESTINO + "</td>";
            //filaHTML += "<td>" + "<a class='btn btn-success' href='javascript:fnListarfotos(\"" + item.NRO_DOCUMENTO + "\");' >Visualizar Album</a>" + "</td>";
            filaHTML += "<td>";
            filaHTML += "</td>";
            filaHTML += "</tr>";
            tablaDatos.append(filaHTML);
        });


    });
}