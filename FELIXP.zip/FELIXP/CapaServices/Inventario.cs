﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;



namespace CapaServices
{
    public class Inventario
    {

        public string GetInventarios()
        {
            string result = "";
            using (SqlConnection conecion = new SqlConnection("Server=localhost;Database=DB_INVENTARIOS;Trusted_Connection=True;"))
            {
                

                try
                {
                    conecion.Open();
                    SqlCommand cmd= conecion.CreateCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "SP_GET_Inventarios";

                    SqlDataReader reader = cmd.ExecuteReader();
                    
                    while (reader.Read()) {

                        result += reader.GetString(0);
                    }


                }
                catch(Exception ex) { 
                

                }



            }


            return result;
        }

    }
}
