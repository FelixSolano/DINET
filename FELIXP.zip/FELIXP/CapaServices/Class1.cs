﻿namespace CapaServices
{
    public class Class1
    {

    }
}
